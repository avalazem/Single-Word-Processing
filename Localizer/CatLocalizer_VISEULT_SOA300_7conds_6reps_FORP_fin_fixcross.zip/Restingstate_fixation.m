% Restingstate script; 
% fixation only; 
% Press esc to exit. 


clear;
KbName('UnifyKeyNames');
AssertOpenGL;

FORP=0;

% check FORP key devices and get device indices
clear PsychHID; 
[keyboardIndices, productNames, allInfos] = GetKeyboardIndices;
% [logicalTrig,locationTrig]=ismember({'Current Designs, Inc. TRIGI-USB'},productNames);% trigger device
% [logicalButt,locationButt]=ismember({'Arduino LLC Arduino Leonardo Keyboard'},productNames);% 2-button device
[logicalKey,locationKey]=ismember({'Dell Dell USB Keyboard'},productNames);% PC keyboard

% devicenumtrigger=allInfos{locationTrig}.index;%temporary
% devicenumresp=allInfos{locationButt}.index;

if FORP
    devicenumkey=allInfos{locationKey}.index;
    deviceind=devicenumkey;
else
    deviceind=-1;
end

%% fixation definition

mainscreen=0;
run=1;

fixwidth=8; % width of the fixation point
fixcolor=[112 219 96]; 
bgcolor=[0 0 0];


% fixwidth=20; % orig=12, fixation width
fixthick=2; % fixation thickness
rng('shuffle');



%% display rectangles & trials
try 
  Priority(MaxPriority(0));
  LoadPsychHID;
  PsychImaging('PrepareConfiguration');
  [w,rect]=PsychImaging('OpenWindow',0,bgcolor);
  Screen('BlendFunction',w,GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
  Screen('TextSize',w,35);
    Screen('Preference', 'DefaultFontStyle',1);
    Screen('Preference', 'VisualDebugLevel',3); % skip the psychtoolbox welcome screen
    HideCursor;
%   Screen('Preference','DefaultFontName','Arial');
% window size
  sxsize=rect(3);
  sysize=rect(4);
  cx=sxsize/2;
  cy=sysize/3;

  hz=Screen('FrameRate',w);
  ifi=Screen('GetFlipInterval',w,100);
  exp_term=0;
ovalrects=[cx-fixwidth/2; cy-fixwidth/2; cx+fixwidth/2; cy+fixwidth/2]; % fixation point (circle)

fixrects=[cx-fixwidth/2    cx-fixthick/2;
          cy-fixthick/2    cy-fixwidth/2;
          cx+fixwidth/2    cx+fixthick/2;
          cy+fixthick/2    cy+fixwidth/2];

% fixation before start
Screen('FillOval',w,fixcolor,ovalrects,fixwidth/2+2);
% Screen('FillRect',w,[255 255 255],fixrects);


Screen('Flip',w);
% img=Screen('GetImage',w);
% imwrite(img,'fixation_screen.png');

keysOfInterest=zeros(1,256);
keysOfInterest(KbName({'q','ESCAPE'}))=1;
PsychHID('KbQueueCreate',deviceind,keysOfInterest);

% run_startTime=GetSecs;
PsychHID('KbQueueStart',deviceind);
 TTL=0; % Get the TTL from the scanner
    while TTL==0
        [KeyIsDown, firstPress]=PsychHID('KbQueueCheck',deviceind); % Collect keyboard events since KbQueueStart was invoked
        if KeyIsDown
            pressedKey=find(firstPress);
            keyname=KbName(pressedKey);
            presstime=firstPress(pressedKey);
            for n=1:size(pressedKey)
                if strcmp(KbName(pressedKey),'9(')==1 % TTL
                    TTL=1;    % Start the experiment
                    run_starttime=GetSecs;
                    PsychHID('KbQueueStop',deviceind);
                    PsychHID('KbQueueRelease',deviceind);
                    break;
                elseif strcmp(KbName(pressedKey),'ESCAPE')==1||strcmp(KbName(pressedKey),'q')==1
                    exp_term=1;
                    PsychHID('KbQueueStop',deviceind);
                    PsychHID('KbQueueRelease',deviceind);
                    break;
                else
                    TTL=0;
                end
            end          
        end
        if exp_term
            Priority(0);
            ShowCursor;
%             PsychHID('KbQueueStop',deviceind);
%             PsychHID('KbQueueRelease',deviceind);
            Screen('CloseAll');
            return;
        end
 
    end
    

run_endtime=GetSecs;
    PsychHID('KbQueueStop',deviceind);
    PsychHID('KbQueueRelease',deviceind);   
ShowCursor;
Priority(0);
Screen('CloseAll');
catch exception
    Screen('CloseAll');
    rethrow(exception)    
end
