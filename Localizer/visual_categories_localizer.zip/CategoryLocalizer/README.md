To start the experiment:

python runVisualCategory.py -s1 -g

(in -sXX XX is the subject number)


After the display of the instructions, press 't' to simulate the TTL scanner trigger.

